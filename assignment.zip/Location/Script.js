const getLocation = document.getElementById("GetLocation");
getLocation.addEventListener('click',evt =>{

    if('geolocation' in navigator){
        navigator.geolocation.getCurrentPosition(position =>{
            let latitude = position.coords.latitude;
            let longitude = position.coords.longitude;
            let googlemapurl = 'https://maps.googleapis.com/maps/api/Staticmap?center=${latitude},${longitude}&zoom=11&size=400x400';
           
            const mapImage = document.getElementById('mapImage');
            mapImage.src = googlemapurl;

            console.log(latitude,longitude);
        }),

    }
    else
    {

        console.log('NOT SUPPORTED')
    }
});